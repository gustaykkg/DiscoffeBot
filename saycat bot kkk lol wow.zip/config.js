module.exports={
    Token: "ODg3MDY0Nzc1ODM2NzA4ODY0.YT-tcw.ZrehSm4FPQjEnWGMaPA6BunfaaY",
    Prefix: "&",
    roles:{
        movcall: "883178013368393860",
        movchat: "887065984509280307",
        muted: "862547019380949033"
    },
    color:{
        sucess: 0x2ecc71,
        err: 0xe74c3c,
        blurple: 0x7289da,
        blue:0x1E90FF,
        green:0x228B22,
        purple:0x483D8B,
        red: 0x850707,
        orange: 0xff9b30,
    },
    channels:{
        sug: "859638263496179712",
        movs: "888123593379172352",
        modlog: "888133183026130954"
    }
}
